-- ============================================
-- BACKUP DE BASE DE DATOS
-- Base de datos: comandero
-- Fecha: 2025-11-19T03:37:47.217Z
-- ============================================

USE `comandero`;

SET NAMES utf8mb4;

SET FOREIGN_KEY_CHECKS = 0;



-- ============================================
-- Estructura de tabla: alerta
-- ============================================

DROP TABLE IF EXISTS `alerta`;

CREATE TABLE `alerta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tipo` varchar(50) NOT NULL COMMENT 'Tipo de alerta: alerta.demora, alerta.cancelacion, etc.',
  `mensaje` varchar(255) NOT NULL,
  `orden_id` bigint(20) unsigned DEFAULT NULL,
  `mesa_id` bigint(20) unsigned DEFAULT NULL,
  `producto_id` bigint(20) unsigned DEFAULT NULL,
  `prioridad` enum('baja','media','alta','urgente') NOT NULL DEFAULT 'media',
  `estacion` varchar(50) DEFAULT NULL COMMENT 'Estación de cocina si aplica',
  `usuario_origen_id` bigint(20) unsigned NOT NULL,
  `usuario_destino_id` bigint(20) unsigned DEFAULT NULL,
  `leida` tinyint(1) NOT NULL DEFAULT 0,
  `leido_por_usuario_id` bigint(20) unsigned DEFAULT NULL,
  `leido_en` timestamp NULL DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_alerta_destino` (`usuario_destino_id`,`leida`,`creado_en`),
  KEY `ix_alerta_mesa` (`mesa_id`),
  KEY `ix_alerta_orden` (`orden_id`),
  KEY `ix_alerta_tipo` (`tipo`),
  KEY `ix_alerta_creado_en` (`creado_en`),
  KEY `fk_alerta_origen` (`usuario_origen_id`),
  KEY `fk_alerta_producto` (`producto_id`),
  KEY `fk_alerta_leido_por` (`leido_por_usuario_id`),
  CONSTRAINT `fk_alerta_destino` FOREIGN KEY (`usuario_destino_id`) REFERENCES `usuario` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_alerta_leido_por` FOREIGN KEY (`leido_por_usuario_id`) REFERENCES `usuario` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_alerta_mesa` FOREIGN KEY (`mesa_id`) REFERENCES `mesa` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_alerta_orden` FOREIGN KEY (`orden_id`) REFERENCES `orden` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_alerta_origen` FOREIGN KEY (`usuario_origen_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_alerta_producto` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: alerta

LOCK TABLES `alerta` WRITE;

INSERT INTO `alerta` (`id`, `tipo`, `mensaje`, `orden_id`, `mesa_id`, `producto_id`, `prioridad`, `estacion`, `usuario_origen_id`, `usuario_destino_id`, `leida`, `leido_por_usuario_id`, `leido_en`, `creado_en`) VALUES

(1, 'alerta.modificacion', 'Orden #3 modificada: Estado cambiado a: abierta', 3, NULL, 1, 'media', NULL, 3, NULL, 0, NULL, NULL, '2025-11-19 03:30:37'),
(2, 'alerta.modificacion', 'Orden #3 modificada: Estado cambiado a: abierta', 3, NULL, 1, 'media', NULL, 3, NULL, 0, NULL, NULL, '2025-11-19 03:30:41');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: bitacora_impresion
-- ============================================

DROP TABLE IF EXISTS `bitacora_impresion`;

CREATE TABLE `bitacora_impresion` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `orden_id` bigint(20) unsigned NOT NULL,
  `usuario_id` bigint(20) unsigned DEFAULT NULL,
  `exito` tinyint(1) NOT NULL DEFAULT 1,
  `mensaje` text DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_orden` (`orden_id`),
  KEY `idx_usuario` (`usuario_id`),
  KEY `idx_creado_en` (`creado_en`),
  CONSTRAINT `bitacora_impresion_ibfk_1` FOREIGN KEY (`orden_id`) REFERENCES `orden` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bitacora_impresion_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla bitacora_impresion está vacía



-- ============================================
-- Estructura de tabla: caja_cierre
-- ============================================

DROP TABLE IF EXISTS `caja_cierre`;

CREATE TABLE `caja_cierre` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `efectivo_inicial` decimal(12,2) NOT NULL DEFAULT 0.00,
  `efectivo_final` decimal(12,2) DEFAULT NULL,
  `total_pagos` decimal(12,2) DEFAULT NULL,
  `total_efectivo` decimal(12,2) DEFAULT NULL,
  `total_tarjeta` decimal(12,2) DEFAULT NULL,
  `creado_por_usuario_id` bigint(20) unsigned DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `notas` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_caja_fecha` (`fecha`),
  KEY `ix_caja_usuario` (`creado_por_usuario_id`),
  CONSTRAINT `fk_caja_usuario` FOREIGN KEY (`creado_por_usuario_id`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla caja_cierre está vacía



-- ============================================
-- Estructura de tabla: categoria
-- ============================================

DROP TABLE IF EXISTS `categoria`;

CREATE TABLE `categoria` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_categoria_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: categoria

LOCK TABLES `categoria` WRITE;

INSERT INTO `categoria` (`id`, `nombre`, `descripcion`, `activo`, `creado_en`, `actualizado_en`) VALUES

(1, 'Tacos', NULL, 1, '2025-11-19 03:24:39', '2025-11-19 03:24:39'),
(2, 'Bebidas', NULL, 1, '2025-11-19 03:25:18', '2025-11-19 03:25:18');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: cliente
-- ============================================

DROP TABLE IF EXISTS `cliente`;

CREATE TABLE `cliente` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(160) NOT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  `email` varchar(190) DEFAULT NULL,
  `notas` varchar(255) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_cliente_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla cliente está vacía



-- ============================================
-- Estructura de tabla: comprobante_tarjeta
-- ============================================

DROP TABLE IF EXISTS `comprobante_tarjeta`;

CREATE TABLE `comprobante_tarjeta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pago_id` bigint(20) unsigned NOT NULL,
  `voucher_id` varchar(120) DEFAULT NULL,
  `autorizacion` varchar(60) DEFAULT NULL,
  `ultimos4` char(4) DEFAULT NULL,
  `marca_tarjeta` varchar(32) DEFAULT NULL,
  `terminal_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_comprobante_pago` (`pago_id`),
  KEY `ix_comp_terminal` (`terminal_id`),
  CONSTRAINT `fk_comp_pago` FOREIGN KEY (`pago_id`) REFERENCES `pago` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_comp_terminal` FOREIGN KEY (`terminal_id`) REFERENCES `terminal` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla comprobante_tarjeta está vacía



-- ============================================
-- Estructura de tabla: conteo_inventario
-- ============================================

DROP TABLE IF EXISTS `conteo_inventario`;

CREATE TABLE `conteo_inventario` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `responsable_usuario_id` bigint(20) unsigned NOT NULL,
  `estado` enum('en_proceso','cerrado','aprobado') NOT NULL DEFAULT 'en_proceso',
  `notas` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_conteo_fecha` (`fecha`),
  KEY `ix_conteo_responsable` (`responsable_usuario_id`),
  CONSTRAINT `fk_conteo_responsable` FOREIGN KEY (`responsable_usuario_id`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla conteo_inventario está vacía



-- ============================================
-- Estructura de tabla: conteo_inventario_item
-- ============================================

DROP TABLE IF EXISTS `conteo_inventario_item`;

CREATE TABLE `conteo_inventario_item` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `conteo_id` bigint(20) unsigned NOT NULL,
  `inventario_item_id` bigint(20) unsigned NOT NULL,
  `cantidad_contada` decimal(12,3) NOT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_conteo_item` (`conteo_id`,`inventario_item_id`),
  KEY `ix_cii_conteo` (`conteo_id`),
  KEY `ix_cii_item` (`inventario_item_id`),
  CONSTRAINT `fk_cii_conteo` FOREIGN KEY (`conteo_id`) REFERENCES `conteo_inventario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_cii_item` FOREIGN KEY (`inventario_item_id`) REFERENCES `inventario_item` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla conteo_inventario_item está vacía



-- ============================================
-- Estructura de tabla: documentacion_pago
-- ============================================

DROP TABLE IF EXISTS `documentacion_pago`;

CREATE TABLE `documentacion_pago` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pago_id` bigint(20) unsigned NOT NULL,
  `url` varchar(512) DEFAULT NULL,
  `tipo_mime` varchar(100) DEFAULT NULL,
  `notas` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_doc_pago` (`pago_id`),
  CONSTRAINT `fk_doc_pago` FOREIGN KEY (`pago_id`) REFERENCES `pago` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla documentacion_pago está vacía



-- ============================================
-- Estructura de tabla: estado_mesa
-- ============================================

DROP TABLE IF EXISTS `estado_mesa`;

CREATE TABLE `estado_mesa` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) NOT NULL,
  `descripcion` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_estado_mesa_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: estado_mesa

LOCK TABLES `estado_mesa` WRITE;

INSERT INTO `estado_mesa` (`id`, `nombre`, `descripcion`) VALUES

(1, 'LIBRE', 'Disponible para asignar'),
(2, 'OCUPADA', 'Con comensales'),
(3, 'RESERVADA', 'Asignada por reserva'),
(4, 'EN_LIMPIEZA', 'En servicio de limpieza');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: estado_orden
-- ============================================

DROP TABLE IF EXISTS `estado_orden`;

CREATE TABLE `estado_orden` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) NOT NULL,
  `descripcion` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_estado_orden_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: estado_orden

LOCK TABLES `estado_orden` WRITE;

INSERT INTO `estado_orden` (`id`, `nombre`, `descripcion`) VALUES

(1, 'abierta', 'En proceso'),
(2, 'pagada', 'Pagada y cerrada'),
(3, 'cancelada', 'Cancelada');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: forma_pago
-- ============================================

DROP TABLE IF EXISTS `forma_pago`;

CREATE TABLE `forma_pago` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) NOT NULL,
  `descripcion` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_forma_pago_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: forma_pago

LOCK TABLES `forma_pago` WRITE;

INSERT INTO `forma_pago` (`id`, `nombre`, `descripcion`) VALUES

(1, 'efectivo', 'Pago en efectivo'),
(2, 'tarjeta_debito', 'Tarjeta de débito'),
(3, 'tarjeta_credito', 'Tarjeta de crédito');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: inventario
-- ============================================

DROP TABLE IF EXISTS `inventario`;

CREATE TABLE `inventario` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `producto_id` bigint(20) NOT NULL,
  `cantidad` decimal(12,3) NOT NULL DEFAULT 0.000,
  `unidad` varchar(30) DEFAULT NULL,
  `minimo` decimal(12,3) NOT NULL DEFAULT 0.000,
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_inventario_producto` (`producto_id`),
  CONSTRAINT `fk_inventario_producto` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla inventario está vacía



-- ============================================
-- Estructura de tabla: inventario_item
-- ============================================

DROP TABLE IF EXISTS `inventario_item`;

CREATE TABLE `inventario_item` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(160) NOT NULL,
  `unidad` varchar(32) NOT NULL,
  `cantidad_actual` decimal(12,3) NOT NULL DEFAULT 0.000,
  `stock_minimo` decimal(12,3) NOT NULL DEFAULT 0.000,
  `costo_unitario` decimal(12,4) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `categoria` varchar(64) NOT NULL DEFAULT 'Otros',
  `proveedor` varchar(120) DEFAULT NULL,
  `stock_maximo` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_inventario_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: inventario_item

LOCK TABLES `inventario_item` WRITE;

INSERT INTO `inventario_item` (`id`, `nombre`, `unidad`, `cantidad_actual`, `stock_minimo`, `costo_unitario`, `activo`, `creado_en`, `actualizado_en`, `categoria`, `proveedor`, `stock_maximo`) VALUES

(1, 'Carne de Barbacoa', 'Kh', '10.000', '1.000', '5000.0000', 1, '2025-11-19 03:34:41', '2025-11-19 03:34:41', 'Carne', 'Carniceria', '30.00');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: mesa
-- ============================================

DROP TABLE IF EXISTS `mesa`;

CREATE TABLE `mesa` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `codigo` varchar(40) NOT NULL,
  `nombre` varchar(80) DEFAULT NULL,
  `capacidad` smallint(5) unsigned DEFAULT NULL,
  `ubicacion` varchar(120) DEFAULT NULL,
  `estado_mesa_id` tinyint(3) unsigned DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_mesa_codigo` (`codigo`),
  KEY `ix_mesa_estado` (`estado_mesa_id`),
  CONSTRAINT `fk_mesa_estado` FOREIGN KEY (`estado_mesa_id`) REFERENCES `estado_mesa` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: mesa

LOCK TABLES `mesa` WRITE;

INSERT INTO `mesa` (`id`, `codigo`, `nombre`, `capacidad`, `ubicacion`, `estado_mesa_id`, `activo`, `creado_en`, `actualizado_en`) VALUES

(1, '9', 'Mesa 9', 4, 'area_principal', 1, 1, '2025-11-19 03:24:10', '2025-11-19 03:24:29');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: mesas
-- ============================================

DROP TABLE IF EXISTS `mesas`;

CREATE TABLE `mesas` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `asientos` int(11) NOT NULL DEFAULT 1,
  `estado` enum('libre','ocupada','reservada') NOT NULL DEFAULT 'libre',
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla mesas está vacía



-- ============================================
-- Estructura de tabla: mesa_estado_hist
-- ============================================

DROP TABLE IF EXISTS `mesa_estado_hist`;

CREATE TABLE `mesa_estado_hist` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mesa_id` bigint(20) unsigned NOT NULL,
  `estado_mesa_id` tinyint(3) unsigned NOT NULL,
  `cambiado_por_usuario_id` bigint(20) unsigned DEFAULT NULL,
  `nota` varchar(255) DEFAULT NULL,
  `cambiado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_meh_mesa` (`mesa_id`,`cambiado_en`),
  KEY `ix_meh_estado` (`estado_mesa_id`),
  KEY `ix_meh_usuario` (`cambiado_por_usuario_id`),
  CONSTRAINT `fk_meh_estado` FOREIGN KEY (`estado_mesa_id`) REFERENCES `estado_mesa` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_meh_mesa` FOREIGN KEY (`mesa_id`) REFERENCES `mesa` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_meh_usuario` FOREIGN KEY (`cambiado_por_usuario_id`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: mesa_estado_hist

LOCK TABLES `mesa_estado_hist` WRITE;

INSERT INTO `mesa_estado_hist` (`id`, `mesa_id`, `estado_mesa_id`, `cambiado_por_usuario_id`, `nota`, `cambiado_en`) VALUES

(1, 1, 1, 1, NULL, '2025-11-19 03:24:13'),
(2, 1, 3, 1, NULL, '2025-11-19 03:24:17'),
(3, 1, 1, 1, NULL, '2025-11-19 03:24:19'),
(4, 1, 1, 1, NULL, '2025-11-19 03:24:23'),
(5, 1, 2, 1, NULL, '2025-11-19 03:24:27'),
(6, 1, 1, 1, NULL, '2025-11-19 03:24:29');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: modificador_categoria
-- ============================================

DROP TABLE IF EXISTS `modificador_categoria`;

CREATE TABLE `modificador_categoria` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  `obligatorio` tinyint(1) NOT NULL DEFAULT 0,
  `max_opciones` tinyint(3) unsigned DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_modcat_nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla modificador_categoria está vacía



-- ============================================
-- Estructura de tabla: modificador_insumo
-- ============================================

DROP TABLE IF EXISTS `modificador_insumo`;

CREATE TABLE `modificador_insumo` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `modificador_opcion_id` bigint(20) unsigned NOT NULL,
  `inventario_item_id` bigint(20) unsigned NOT NULL,
  `cantidad_porcion` decimal(12,3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_modins_opcion_item` (`modificador_opcion_id`,`inventario_item_id`),
  KEY `fk_modins_item` (`inventario_item_id`),
  CONSTRAINT `fk_modins_item` FOREIGN KEY (`inventario_item_id`) REFERENCES `inventario_item` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_modins_opcion` FOREIGN KEY (`modificador_opcion_id`) REFERENCES `modificador_opcion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla modificador_insumo está vacía



-- ============================================
-- Estructura de tabla: modificador_opcion
-- ============================================

DROP TABLE IF EXISTS `modificador_opcion`;

CREATE TABLE `modificador_opcion` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `categoria_id` bigint(20) unsigned NOT NULL,
  `nombre` varchar(120) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL DEFAULT 0.00,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_modopc_cat_nombre` (`categoria_id`,`nombre`),
  KEY `ix_modopc_cat` (`categoria_id`),
  CONSTRAINT `fk_modopc_cat` FOREIGN KEY (`categoria_id`) REFERENCES `modificador_categoria` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla modificador_opcion está vacía



-- ============================================
-- Estructura de tabla: movimiento_caja
-- ============================================

DROP TABLE IF EXISTS `movimiento_caja`;

CREATE TABLE `movimiento_caja` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `caja_cierre_id` bigint(20) unsigned NOT NULL,
  `tipo` enum('ingreso','retiro','ajuste') NOT NULL,
  `monto` decimal(12,2) NOT NULL,
  `referencia` varchar(160) DEFAULT NULL,
  `creado_por_usuario_id` bigint(20) unsigned DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_movcaja_caja` (`caja_cierre_id`,`creado_en`),
  KEY `ix_movcaja_usuario` (`creado_por_usuario_id`),
  CONSTRAINT `fk_movcaja_caja` FOREIGN KEY (`caja_cierre_id`) REFERENCES `caja_cierre` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_movcaja_usuario` FOREIGN KEY (`creado_por_usuario_id`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla movimiento_caja está vacía



-- ============================================
-- Estructura de tabla: movimiento_inventario
-- ============================================

DROP TABLE IF EXISTS `movimiento_inventario`;

CREATE TABLE `movimiento_inventario` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `inventario_item_id` bigint(20) unsigned NOT NULL,
  `tipo` enum('entrada','salida','ajuste') NOT NULL,
  `cantidad` decimal(12,3) NOT NULL,
  `costo_unitario` decimal(12,4) DEFAULT NULL,
  `motivo` varchar(160) DEFAULT NULL,
  `origen` enum('compra','consumo','ajuste','devolucion') DEFAULT NULL,
  `referencia_orden_id` bigint(20) unsigned DEFAULT NULL,
  `creado_por_usuario_id` bigint(20) unsigned DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_movi_item` (`inventario_item_id`,`creado_en`),
  KEY `ix_movi_orden` (`referencia_orden_id`),
  KEY `ix_movi_usuario` (`creado_por_usuario_id`),
  CONSTRAINT `fk_movi_item` FOREIGN KEY (`inventario_item_id`) REFERENCES `inventario_item` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_movi_orden` FOREIGN KEY (`referencia_orden_id`) REFERENCES `orden` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_movi_usuario` FOREIGN KEY (`creado_por_usuario_id`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla movimiento_inventario está vacía



-- ============================================
-- Estructura de tabla: nota_orden
-- ============================================

DROP TABLE IF EXISTS `nota_orden`;

CREATE TABLE `nota_orden` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `orden_id` bigint(20) unsigned NOT NULL,
  `texto` text NOT NULL,
  `creado_por_usuario_id` bigint(20) unsigned DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_nota_orden` (`orden_id`,`creado_en`),
  KEY `fk_nota_usuario` (`creado_por_usuario_id`),
  CONSTRAINT `fk_nota_orden` FOREIGN KEY (`orden_id`) REFERENCES `orden` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_nota_usuario` FOREIGN KEY (`creado_por_usuario_id`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla nota_orden está vacía



-- ============================================
-- Estructura de tabla: orden
-- ============================================

DROP TABLE IF EXISTS `orden`;

CREATE TABLE `orden` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mesa_id` bigint(20) unsigned DEFAULT NULL,
  `reserva_id` bigint(20) unsigned DEFAULT NULL,
  `cliente_id` bigint(20) unsigned DEFAULT NULL,
  `cliente_nombre` varchar(160) DEFAULT NULL,
  `subtotal` decimal(12,2) NOT NULL DEFAULT 0.00,
  `descuento_total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `impuesto_total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `propina_sugerida` decimal(12,2) DEFAULT NULL,
  `total` decimal(12,2) NOT NULL DEFAULT 0.00,
  `estado_orden_id` tinyint(3) unsigned NOT NULL,
  `creado_por_usuario_id` bigint(20) unsigned DEFAULT NULL,
  `cerrado_por_usuario_id` bigint(20) unsigned DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_orden_mesa` (`mesa_id`),
  KEY `ix_orden_reserva` (`reserva_id`),
  KEY `ix_orden_cliente` (`cliente_id`),
  KEY `ix_orden_estado` (`estado_orden_id`),
  KEY `ix_orden_usuario` (`creado_por_usuario_id`),
  KEY `fk_orden_cerrado_por` (`cerrado_por_usuario_id`),
  CONSTRAINT `fk_orden_cerrado_por` FOREIGN KEY (`cerrado_por_usuario_id`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_orden_cliente` FOREIGN KEY (`cliente_id`) REFERENCES `cliente` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_orden_creado_por` FOREIGN KEY (`creado_por_usuario_id`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_orden_estado` FOREIGN KEY (`estado_orden_id`) REFERENCES `estado_orden` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_orden_mesa` FOREIGN KEY (`mesa_id`) REFERENCES `mesa` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_orden_reserva` FOREIGN KEY (`reserva_id`) REFERENCES `reserva` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: orden

LOCK TABLES `orden` WRITE;

INSERT INTO `orden` (`id`, `mesa_id`, `reserva_id`, `cliente_id`, `cliente_nombre`, `subtotal`, `descuento_total`, `impuesto_total`, `propina_sugerida`, `total`, `estado_orden_id`, `creado_por_usuario_id`, `cerrado_por_usuario_id`, `creado_en`, `actualizado_en`) VALUES

(1, 1, NULL, NULL, NULL, '25.00', '0.00', '0.00', NULL, '25.00', 1, 2, NULL, '2025-11-19 03:29:08', '2025-11-19 03:29:08'),
(2, 1, NULL, NULL, NULL, '25.00', '0.00', '0.00', NULL, '25.00', 1, 2, NULL, '2025-11-19 03:29:15', '2025-11-19 03:29:15'),
(3, 1, NULL, NULL, NULL, '25.00', '0.00', '0.00', NULL, '25.00', 1, 2, NULL, '2025-11-19 03:29:22', '2025-11-19 03:30:41');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: orden_cancelacion
-- ============================================

DROP TABLE IF EXISTS `orden_cancelacion`;

CREATE TABLE `orden_cancelacion` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `orden_id` bigint(20) unsigned NOT NULL,
  `motivo` varchar(255) DEFAULT NULL,
  `cancelado_por_usuario_id` bigint(20) unsigned DEFAULT NULL,
  `cancelado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_cancelacion_orden` (`orden_id`),
  KEY `ix_cancelacion_usuario` (`cancelado_por_usuario_id`),
  CONSTRAINT `fk_cancelacion_orden` FOREIGN KEY (`orden_id`) REFERENCES `orden` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_cancelacion_usuario` FOREIGN KEY (`cancelado_por_usuario_id`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla orden_cancelacion está vacía



-- ============================================
-- Estructura de tabla: orden_item
-- ============================================

DROP TABLE IF EXISTS `orden_item`;

CREATE TABLE `orden_item` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `orden_id` bigint(20) unsigned NOT NULL,
  `producto_id` bigint(20) unsigned NOT NULL,
  `producto_tamano_id` bigint(20) unsigned DEFAULT NULL,
  `cantidad` decimal(8,3) NOT NULL DEFAULT 1.000,
  `precio_unitario` decimal(10,2) NOT NULL,
  `total_linea` decimal(12,2) NOT NULL DEFAULT 0.00,
  `nota` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_oi_orden` (`orden_id`),
  KEY `ix_oi_producto` (`producto_id`),
  KEY `ix_oi_tamano` (`producto_tamano_id`),
  CONSTRAINT `fk_oi_orden` FOREIGN KEY (`orden_id`) REFERENCES `orden` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_oi_producto` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_oi_tamano` FOREIGN KEY (`producto_tamano_id`) REFERENCES `producto_tamano` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: orden_item

LOCK TABLES `orden_item` WRITE;

INSERT INTO `orden_item` (`id`, `orden_id`, `producto_id`, `producto_tamano_id`, `cantidad`, `precio_unitario`, `total_linea`, `nota`, `creado_en`) VALUES

(1, 1, 1, NULL, '1.000', '25.00', '25.00', NULL, '2025-11-19 03:29:08'),
(2, 2, 1, NULL, '1.000', '25.00', '25.00', NULL, '2025-11-19 03:29:15'),
(3, 3, 1, NULL, '1.000', '25.00', '25.00', NULL, '2025-11-19 03:29:22');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: orden_item_modificador
-- ============================================

DROP TABLE IF EXISTS `orden_item_modificador`;

CREATE TABLE `orden_item_modificador` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `orden_item_id` bigint(20) unsigned NOT NULL,
  `modificador_opcion_id` bigint(20) unsigned NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_item_opcion` (`orden_item_id`,`modificador_opcion_id`),
  KEY `ix_oim_item` (`orden_item_id`),
  KEY `ix_oim_opcion` (`modificador_opcion_id`),
  CONSTRAINT `fk_oim_item` FOREIGN KEY (`orden_item_id`) REFERENCES `orden_item` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_oim_opcion` FOREIGN KEY (`modificador_opcion_id`) REFERENCES `modificador_opcion` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla orden_item_modificador está vacía



-- ============================================
-- Estructura de tabla: pago
-- ============================================

DROP TABLE IF EXISTS `pago`;

CREATE TABLE `pago` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `orden_id` bigint(20) unsigned NOT NULL,
  `forma_pago_id` tinyint(3) unsigned NOT NULL,
  `monto` decimal(12,2) NOT NULL,
  `referencia` varchar(120) DEFAULT NULL,
  `estado` enum('aplicado','anulado','pendiente') NOT NULL DEFAULT 'aplicado',
  `fecha_pago` datetime NOT NULL DEFAULT current_timestamp(),
  `empleado_id` bigint(20) unsigned DEFAULT NULL,
  `caja_cierre_id` bigint(20) unsigned DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_pago_orden` (`orden_id`),
  KEY `ix_pago_forma` (`forma_pago_id`),
  KEY `ix_pago_caja` (`caja_cierre_id`),
  KEY `ix_pago_empleado` (`empleado_id`),
  CONSTRAINT `fk_pago_caja` FOREIGN KEY (`caja_cierre_id`) REFERENCES `caja_cierre` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_pago_empleado` FOREIGN KEY (`empleado_id`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_pago_forma` FOREIGN KEY (`forma_pago_id`) REFERENCES `forma_pago` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_pago_orden` FOREIGN KEY (`orden_id`) REFERENCES `orden` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla pago está vacía



-- ============================================
-- Estructura de tabla: permiso
-- ============================================

DROP TABLE IF EXISTS `permiso`;

CREATE TABLE `permiso` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_permiso_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: permiso

LOCK TABLES `permiso` WRITE;

INSERT INTO `permiso` (`id`, `nombre`, `descripcion`, `creado_en`, `actualizado_en`) VALUES

(1, 'ver_caja', 'Puede ver módulo de caja', '2025-11-19 02:58:01', '2025-11-19 02:58:01'),
(2, 'cerrar_caja', 'Puede ejecutar cierre de caja', '2025-11-19 02:58:01', '2025-11-19 02:58:01'),
(3, 'editar_menu', 'Puede administrar catálogo de productos', '2025-11-19 02:58:01', '2025-11-19 02:58:01');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: preparacion_orden
-- ============================================

DROP TABLE IF EXISTS `preparacion_orden`;

CREATE TABLE `preparacion_orden` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `orden_id` bigint(20) unsigned NOT NULL,
  `orden_item_id` bigint(20) unsigned DEFAULT NULL,
  `asignado_a_usuario_id` bigint(20) unsigned DEFAULT NULL,
  `estado_preparacion` enum('pendiente','en_preparacion','listo','entregado','cancelado') NOT NULL DEFAULT 'pendiente',
  `prioridad` tinyint(3) unsigned DEFAULT NULL,
  `tiempo_inicio` datetime DEFAULT NULL,
  `tiempo_fin` datetime DEFAULT NULL,
  `notas` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_prep_orden` (`orden_id`),
  KEY `ix_prep_item` (`orden_item_id`),
  KEY `ix_prep_asignado` (`asignado_a_usuario_id`),
  CONSTRAINT `fk_prep_item` FOREIGN KEY (`orden_item_id`) REFERENCES `orden_item` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_prep_orden` FOREIGN KEY (`orden_id`) REFERENCES `orden` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_prep_usuario` FOREIGN KEY (`asignado_a_usuario_id`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla preparacion_orden está vacía



-- ============================================
-- Estructura de tabla: producto
-- ============================================

DROP TABLE IF EXISTS `producto`;

CREATE TABLE `producto` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `categoria_id` bigint(20) unsigned NOT NULL,
  `nombre` varchar(160) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL,
  `disponible` tinyint(1) NOT NULL DEFAULT 1,
  `sku` varchar(64) DEFAULT NULL,
  `inventariable` tinyint(1) NOT NULL DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_producto_categoria_nombre` (`categoria_id`,`nombre`),
  KEY `ix_producto_categoria` (`categoria_id`),
  CONSTRAINT `fk_producto_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `categoria` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: producto

LOCK TABLES `producto` WRITE;

INSERT INTO `producto` (`id`, `categoria_id`, `nombre`, `descripcion`, `precio`, `disponible`, `sku`, `inventariable`, `creado_en`, `actualizado_en`) VALUES

(1, 1, 'Taco de Barbacoa', 'Taco de barbacoa suave', '25.00', 1, NULL, 0, '2025-11-19 03:25:05', '2025-11-19 03:25:05'),
(2, 2, 'Agua de Jamaica Hecha en Casa', 'Agua de jamaica casera sabrosa', '20.00', 1, NULL, 0, '2025-11-19 03:26:18', '2025-11-19 03:26:35');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: productos
-- ============================================

DROP TABLE IF EXISTS `productos`;

CREATE TABLE `productos` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `precio` decimal(10,2) NOT NULL DEFAULT 0.00,
  `disponible` tinyint(1) NOT NULL DEFAULT 1,
  `sku` varchar(80) DEFAULT NULL,
  `url_imagen` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: productos

LOCK TABLES `productos` WRITE;

INSERT INTO `productos` (`id`, `nombre`, `descripcion`, `precio`, `disponible`, `sku`, `url_imagen`, `creado_en`, `actualizado_en`) VALUES

(1, 'Taco de pastor', 'Taco tradicional con salsa', '25.00', 1, 'TAC-001', NULL, '2025-09-04 22:29:08', '2025-09-04 22:29:08'),
(2, 'Agua natural', 'Botella 600ml', '12.00', 1, 'BEB-001', NULL, '2025-09-04 22:29:08', '2025-09-04 22:29:08');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: producto_insumo
-- ============================================

DROP TABLE IF EXISTS `producto_insumo`;

CREATE TABLE `producto_insumo` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `producto_id` bigint(20) unsigned NOT NULL,
  `inventario_item_id` bigint(20) unsigned NOT NULL,
  `cantidad_porcion` decimal(12,3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_producto_insumo` (`producto_id`,`inventario_item_id`),
  KEY `ix_pi_producto` (`producto_id`),
  KEY `ix_pi_insumo` (`inventario_item_id`),
  CONSTRAINT `fk_pi_insumo` FOREIGN KEY (`inventario_item_id`) REFERENCES `inventario_item` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_pi_producto` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla producto_insumo está vacía



-- ============================================
-- Estructura de tabla: producto_modificador
-- ============================================

DROP TABLE IF EXISTS `producto_modificador`;

CREATE TABLE `producto_modificador` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `producto_id` bigint(20) unsigned NOT NULL,
  `categoria_id` bigint(20) unsigned NOT NULL,
  `obligatorio` tinyint(1) NOT NULL DEFAULT 0,
  `max_opciones` tinyint(3) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_prod_mod` (`producto_id`,`categoria_id`),
  KEY `ix_pm_producto` (`producto_id`),
  KEY `ix_pm_categoria` (`categoria_id`),
  CONSTRAINT `fk_pm_categoria` FOREIGN KEY (`categoria_id`) REFERENCES `modificador_categoria` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_pm_producto` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla producto_modificador está vacía



-- ============================================
-- Estructura de tabla: producto_tamano
-- ============================================

DROP TABLE IF EXISTS `producto_tamano`;

CREATE TABLE `producto_tamano` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `producto_id` bigint(20) unsigned NOT NULL,
  `etiqueta` varchar(60) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_pt_producto_etiqueta` (`producto_id`,`etiqueta`),
  KEY `ix_pt_producto` (`producto_id`),
  CONSTRAINT `fk_pt_producto` FOREIGN KEY (`producto_id`) REFERENCES `producto` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: producto_tamano

LOCK TABLES `producto_tamano` WRITE;

INSERT INTO `producto_tamano` (`id`, `producto_id`, `etiqueta`, `precio`, `activo`, `creado_en`, `actualizado_en`) VALUES

(4, 2, 'Chica', '20.00', 1, '2025-11-19 03:26:36', '2025-11-19 03:26:36'),
(5, 2, 'Mediana', '25.00', 1, '2025-11-19 03:26:36', '2025-11-19 03:26:36'),
(6, 2, 'Grande', '30.00', 1, '2025-11-19 03:26:36', '2025-11-19 03:26:36');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: propina
-- ============================================

DROP TABLE IF EXISTS `propina`;

CREATE TABLE `propina` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `orden_id` bigint(20) unsigned NOT NULL,
  `monto` decimal(12,2) NOT NULL,
  `registrado_por_usuario_id` bigint(20) unsigned DEFAULT NULL,
  `fecha` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_propina_orden` (`orden_id`),
  KEY `ix_propina_usuario` (`registrado_por_usuario_id`),
  CONSTRAINT `fk_propina_orden` FOREIGN KEY (`orden_id`) REFERENCES `orden` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_propina_usuario` FOREIGN KEY (`registrado_por_usuario_id`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla propina está vacía



-- ============================================
-- Estructura de tabla: reserva
-- ============================================

DROP TABLE IF EXISTS `reserva`;

CREATE TABLE `reserva` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `mesa_id` bigint(20) unsigned NOT NULL,
  `nombre_cliente` varchar(120) DEFAULT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  `fecha_hora_inicio` datetime NOT NULL,
  `fecha_hora_fin` datetime DEFAULT NULL,
  `estado` enum('pendiente','confirmada','cancelada','no_show') NOT NULL DEFAULT 'pendiente',
  `creado_por_usuario_id` bigint(20) unsigned DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_reserva_mesa` (`mesa_id`,`fecha_hora_inicio`),
  KEY `ix_reserva_usuario` (`creado_por_usuario_id`),
  CONSTRAINT `fk_reserva_mesa` FOREIGN KEY (`mesa_id`) REFERENCES `mesa` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_reserva_usuario` FOREIGN KEY (`creado_por_usuario_id`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla reserva está vacía



-- ============================================
-- Estructura de tabla: rol
-- ============================================

DROP TABLE IF EXISTS `rol`;

CREATE TABLE `rol` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(80) NOT NULL,
  `descripcion` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_rol_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: rol

LOCK TABLES `rol` WRITE;

INSERT INTO `rol` (`id`, `nombre`, `descripcion`, `creado_en`, `actualizado_en`) VALUES

(1, 'administrador', 'Acceso total', '2025-11-19 02:58:00', '2025-11-19 02:58:00'),
(2, 'cajero', 'Caja y pagos', '2025-11-19 02:58:00', '2025-11-19 02:58:00'),
(3, 'capitan', 'Coordina sala', '2025-11-19 02:58:00', '2025-11-19 02:58:00'),
(4, 'mesero', 'Toma órdenes', '2025-11-19 02:58:00', '2025-11-19 02:58:00'),
(5, 'cocinero', 'KDS cocina', '2025-11-19 02:58:00', '2025-11-19 02:58:00');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: rol_permiso
-- ============================================

DROP TABLE IF EXISTS `rol_permiso`;

CREATE TABLE `rol_permiso` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rol_id` bigint(20) unsigned NOT NULL,
  `permiso_id` bigint(20) unsigned NOT NULL,
  `asignado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_rol_permiso` (`rol_id`,`permiso_id`),
  KEY `ix_rol_permiso_rol` (`rol_id`),
  KEY `ix_rol_permiso_permiso` (`permiso_id`),
  CONSTRAINT `fk_rol_permiso_permiso` FOREIGN KEY (`permiso_id`) REFERENCES `permiso` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rol_permiso_rol` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla rol_permiso está vacía



-- ============================================
-- Estructura de tabla: terminal
-- ============================================

DROP TABLE IF EXISTS `terminal`;

CREATE TABLE `terminal` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `modelo` varchar(80) DEFAULT NULL,
  `ubicacion` varchar(120) DEFAULT NULL,
  `numero_serie` varchar(120) DEFAULT NULL,
  `activo` tinyint(4) NOT NULL DEFAULT 1,
  `conectado` tinyint(4) NOT NULL DEFAULT 0,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_terminal_serie` (`numero_serie`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla terminal está vacía



-- ============================================
-- Estructura de tabla: terminal_log
-- ============================================

DROP TABLE IF EXISTS `terminal_log`;

CREATE TABLE `terminal_log` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `terminal_id` bigint(20) unsigned NOT NULL,
  `tipo` enum('info','warn','error') NOT NULL DEFAULT 'info',
  `mensaje` varchar(255) NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`payload`)),
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_tlog_terminal` (`terminal_id`,`creado_en`),
  CONSTRAINT `fk_tlog_terminal` FOREIGN KEY (`terminal_id`) REFERENCES `terminal` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla terminal_log está vacía



-- ============================================
-- Estructura de tabla: usuario
-- ============================================

DROP TABLE IF EXISTS `usuario`;

CREATE TABLE `usuario` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `username` varchar(100) NOT NULL,
  `telefono` varchar(40) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `ultimo_acceso` timestamp NULL DEFAULT NULL,
  `password_actualizada_en` timestamp NULL DEFAULT NULL,
  `password_actualizada_por_usuario_id` bigint(20) unsigned DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_username` (`username`),
  KEY `idx_activo` (`activo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: usuario

LOCK TABLES `usuario` WRITE;

INSERT INTO `usuario` (`id`, `nombre`, `username`, `telefono`, `password_hash`, `activo`, `ultimo_acceso`, `password_actualizada_en`, `password_actualizada_por_usuario_id`, `creado_en`, `actualizado_en`) VALUES

(1, 'Administrador', 'admin', '555-0001', '$2b$10$Kjdg7y4OIzYQso4HmTJK/u78hmqep5fxhviBa0XKoi1aS7.3Ds6he', 1, '2025-11-19 03:33:40', '2025-11-19 02:28:41', NULL, '2025-11-19 02:28:41', '2025-11-19 03:33:40'),
(2, 'Mesero', 'mesero', '5578903728', '$2b$12$488Kw8zGR.4AWDtxs0pYLe1C7lUSbYTgIFCiL4Mow5rlQ5rc0jvSK', 1, '2025-11-19 03:31:17', '2025-11-19 03:16:47', 1, '2025-11-19 03:16:47', '2025-11-19 03:31:17'),
(3, 'Cocinero', 'cocinero', '5578902613', '$2b$12$kL0aHvggX7pAh7e/mVXdIOjNT1O/bk8Ev6uMz5cX5Evh5V09wiG0W', 1, '2025-11-19 03:30:28', '2025-11-19 03:17:46', 1, '2025-11-19 03:17:46', '2025-11-19 03:30:28'),
(4, 'Cajero', 'cajero', '5578361936', '$2b$12$LM6lvW6WsFgUOSDR/TZOvOspMVyS8Hl4w75/QFLjYFtMIh8FcPsm6', 1, '2025-11-19 03:31:39', '2025-11-19 03:18:26', 1, '2025-11-19 03:18:26', '2025-11-19 03:31:39'),
(5, 'Capitan', 'capitan', '5587905439', '$2b$12$4wE5GLz9K1qI.XPclOP.ZOgq7cNGUm4YDmNlxmYeT24q.O3gUus/K', 1, '2025-11-19 03:37:11', '2025-11-19 03:18:57', 1, '2025-11-19 03:18:57', '2025-11-19 03:37:11');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: usuarios
-- ============================================

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(120) NOT NULL,
  `correo` varchar(160) NOT NULL,
  `contraseña_hash` varchar(255) NOT NULL,
  `rol` enum('admin','mesero') NOT NULL DEFAULT 'mesero',
  `activo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: usuarios

LOCK TABLES `usuarios` WRITE;

INSERT INTO `usuarios` (`id`, `nombre`, `correo`, `contraseña_hash`, `rol`, `activo`, `creado_en`, `actualizado_en`) VALUES

(1, 'Administrador', 'admin@local', '$2b$12$nyf/hjUeUfHMZ8u014E3m.76DpGlWw3Rk/bYCwViu0FC.7WwJ0JQe', 'admin', 1, '2025-09-05 22:21:36', '2025-11-19 02:02:24');


UNLOCK TABLES;



-- ============================================
-- Estructura de tabla: usuario_password_hist
-- ============================================

DROP TABLE IF EXISTS `usuario_password_hist`;

CREATE TABLE `usuario_password_hist` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` bigint(20) unsigned NOT NULL,
  `cambiado_por_usuario_id` bigint(20) unsigned NOT NULL,
  `metodo` enum('admin_cambio','admin_reset','creacion') NOT NULL DEFAULT 'admin_cambio',
  `notas` varchar(255) DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ix_uph_usuario` (`usuario_id`,`creado_en`),
  KEY `ix_uph_admin` (`cambiado_por_usuario_id`,`creado_en`),
  CONSTRAINT `fk_uph_admin` FOREIGN KEY (`cambiado_por_usuario_id`) REFERENCES `usuario` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_uph_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabla usuario_password_hist está vacía



-- ============================================
-- Estructura de tabla: usuario_rol
-- ============================================

DROP TABLE IF EXISTS `usuario_rol`;

CREATE TABLE `usuario_rol` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `usuario_id` bigint(20) unsigned NOT NULL,
  `rol_id` bigint(20) unsigned NOT NULL,
  `asignado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_usuario_rol` (`usuario_id`,`rol_id`),
  KEY `ix_usuario_rol_usuario` (`usuario_id`),
  KEY `ix_usuario_rol_rol` (`rol_id`),
  CONSTRAINT `fk_usuario_rol_rol` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_usuario_rol_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Datos de tabla: usuario_rol

LOCK TABLES `usuario_rol` WRITE;

INSERT INTO `usuario_rol` (`id`, `usuario_id`, `rol_id`, `asignado_en`) VALUES

(1, 1, 1, '2025-11-19 02:58:01'),
(2, 2, 4, '2025-11-19 03:16:47'),
(3, 3, 5, '2025-11-19 03:17:46'),
(4, 4, 2, '2025-11-19 03:18:26'),
(5, 5, 3, '2025-11-19 03:18:57');


UNLOCK TABLES;


SET FOREIGN_KEY_CHECKS = 1;
